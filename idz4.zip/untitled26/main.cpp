#include <iostream>
#include <pthread.h>

pthread_mutex_t myMutex;

// Количество потоков
int threadNum = 0;
// Переменная, которая имитирует поиск меда
int collecting = 10;
// Количество пчёл, которые пошли рабоать
static int cntBee = 30;
// Количества меда в улее
static int cntHoney = 0;
// Время собирания меда для пчел
static int timeToGather = 1000000;
static bool beatedBear = true;

// сборка меда для пчёл
void *collectHoney(void *param)
{
  pthread_mutex_lock(&myMutex);
  cntBee--;
  // Если в улее достаточно меда, то мы отправляем дополнительных пчел
  // чтобы в улее было свободнее
  if (cntHoney > 30) {
    cntBee--;
  } else {
    cntHoney++;
  }
  // Иммитация сборки меда
  for (int i = 0; i < timeToGather; ++i) {
    collecting++;
    collecting--;
  }
  threadNum++;
  std::cout << "Bees number " << threadNum - 1 << " finished collecting!\n";
  cntBee++;
  pthread_mutex_unlock(&myMutex);
}

void getHoney() {
  // Сборка мёда медведем
  std::cout << "Bear started gathering honey!\n";
  // Если пчел больше трех, то медведя кусают
  if (cntBee > 3 && beatedBear) {
    beatedBear = false;
    std::cout << "Bear was bited by BEES!\n";
    std::cout << cntBee << " bees in the hive!\n";
  } else {
    // Иначе медведь собирает мёд и идёт спать
    cntHoney = 0;
    std::cout << cntBee - cntBee + 2 << " bees in the hive!\n";
    std::cout << "Bear gathered HONEY!!!\n";

  }
}

int main(int argc, char** argv)
{
  // Вводим количество пчёл
  std::cin >> cntBee;
  // Потоки пчёл
  pthread_t bees[cntBee];
  // Инициализация мьютекса
  pthread_mutex_init(&myMutex,0);
  // Запускаем пчёл на сбор меда!
  for (int i = 0; i < cntBee; ++i) {
    // Выпускаем пчёл на сборку
    pthread_create(&bees[i], 0, collectHoney, (void *) i);
    std::cout << "Bees thread " << i << " was started\n";
  }
  // Тут также происходит циклическое освобождение улья от меда
  for (int i = 0; i < cntBee; ++i) {
    // Если меда в улее больше, 30, выходит медведь!
    if (cntHoney == 30) {
      getHoney();
    }
    pthread_join(bees[i], 0);
    std::cout << "Bees thread " << i << " was finished\n";
  }
  // Уничтожаем мьютекс
  pthread_mutex_destroy(&myMutex);
  return 0;
}