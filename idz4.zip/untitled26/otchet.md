# ИДЗ4,  Романчукевич БПИ216 

## Вариант 3.
## Задание:
Задача о Винни-Пухе - 2 или неправильные пчелы. N пчел живет в улье,
каждая пчела может собирать мед и сторожить улей (N > 3). Пчела не покинет улей, если кроме нее в нем нет других пчел. Каждая пчела приносит за раз одну порцию меда. Всего в улей может войти тридцать порций меда.
Вини-Пух спит пока меда в улье меньше половины, но как только его становится достаточно, он просыпается и пытается достать весь мед из улья. Если в улье находится менее чем три пчелы, Вини-Пух забирает мед, убегает, съедает мед и снова засыпает. Если в улье пчел больше, они кусают Вини-Пуха,
он убегает, лечит укус, и снова бежит за медом. Создать многопоточное
приложение, моделирующее поведение пчел и медведя. Осуществить балансировку, обеспечивающую циклическое освобождение улья от меда.

## Ввод в консоль:
Входные данные: n

n, это количество пчёл

Нужно вводить больше 30, чтобы пчелы смогли собрать достаточное количество меда, чтобы проснулся медведь.
## Модель параллельных вычислений:
Использую циклическое освобождение улья от меда, чтобы медьведь смог всё собрать, пока пчёлы на работе.

## Отчет:
- 6 балла:

1) Приведено условие задачи.
2) Описана модель параллельных вычислений, используемая при разработке многопоточной программы.
3) Описаны входные данные программы, включающие вариативные
диапазоны, возможные при многократных запусках.
4) Реализовано консольное приложение, решающее поставленную задачу с использованием одного варианта синхропримитивов
5) Ввод данных в приложение реализован с консоли.
6) Результаты работы приведены в отчете.
7) В программу добавлены комментарии, поясняющие выполняемые
действия и описание используемых переменных.
8) В отчете должен быть приведен сценарий, описывающий одновре-
менное поведение представленных в условии задания сущностей в
терминах предметной области. То есть, описано поведение объектов
разрабатываемой программы как взаимодействующих субъектов, а
не то, как это будет реализовано в программе.
7) Был реализован метод, который запускается при создании потока


## Код на C++
В некоторых местах я использовала циклы, чтобы иммитировать работу пчёл. Таким образом медведь успевает собрать весь мёд.

```Cpp
#include <iostream>
#include <pthread.h>

pthread_mutex_t myMutex; 

// Количество потоков
int threadNum = 0;
// Переменная, которая имитирует поиск меда
int collecting = 10;
// Количество пчёл, которые пошли рабоать
static int cntBee = 30;
// Количества меда в улее
static int cntHoney = 0;
// Время собирания меда для пчел
static int timeToGather = 1000000;
static bool beatedBear = true;

// сборка меда для пчёл
void *collectHoney(void *param)
{
  pthread_mutex_lock(&myMutex);
  cntBee--;
  // Если в улее достаточно меда, то мы отправляем дополнительных пчел
  // чтобы в улее было свободнее
  if (cntHoney > 30) {
    cntBee--;
  } else {
    cntHoney++;
  }
  // Иммитация сборки меда
  for (int i = 0; i < timeToGather; ++i) {
    collecting++;
    collecting--;
  }
  threadNum++;
  std::cout << "Bees number " << threadNum - 1 << " finished collecting!\n";
  cntBee++;
  pthread_mutex_unlock(&myMutex);
}

void getHoney() {
  // Сборка мёда медведем
  std::cout << "Bear started gathering honey!\n";
  // Если пчел больше трех, то медведя кусают
  if (cntBee > 3 && beatedBear) {
    beatedBear = false;
    std::cout << "Bear was bited by BEES!\n";
    std::cout << cntBee << " bees in the hive!\n";
  } else {
    // Иначе медведь собирает мёд и идёт спать
    cntHoney = 0;
    std::cout << cntBee - cntBee + 2 << " bees in the hive!\n";
    std::cout << "Bear gathered HONEY!!!\n";

  }
}

int main(int argc, char** argv)
{
  // Вводим количество пчёл
  std::cin >> cntBee;
  // Потоки пчёл
  pthread_t bees[cntBee];
  // Инициализация мьютекса
  pthread_mutex_init(&myMutex,0);
  // Запускаем пчёл на сбор меда!
  for (int i = 0; i < cntBee; ++i) {
    // Выпускаем пчёл на сборку
    pthread_create(&bees[i], 0, collectHoney, (void *) i);
    std::cout << "Bees thread " << i << " was started\n";
  }
  // Тут также происходит циклическое освобождение улья от меда
  for (int i = 0; i < cntBee; ++i) {
    // Если меда в улее больше, 30, выходит медведь!
    if (cntHoney == 30) {
      getHoney();
    }
    pthread_join(bees[i], 0);
    std::cout << "Bees thread " << i << " was finished\n";
  }
  // Уничтожаем мьютекс
  pthread_mutex_destroy(&myMutex);
  return 0;
}
```
Получается, что создается поток при котором пчелы начинают работать. Также, если в улье количество меда 30, тогда медведь выходит на сбор, тем самым в цикле медведь собирает весь полученный мёд, который пчёлы успели собрать.

## Выходные данные:
```
40
Bees thread 0 was started
Bees thread 1 was started
Bees number 0 finished collecting!
Bees thread 2 was started
Bees thread 3 was started
Bees thread 4 was started
Bees thread 5 was started
Bees thread 6 was started
Bees thread 7 was started
Bees number 1 finished collecting!
Bees thread 8 was started
Bees thread 9 was started
Bees thread 10 was started
Bees thread 11 was started
Bees number 2 finished collecting!
Bees thread 12 was started
Bees thread 13 was started
Bees thread 14 was started
Bees thread 15 was started
Bees number 3 finished collecting!
Bees thread 16 was started
Bees thread 17 was started
Bees thread 18 was started
Bees thread 19 was started
Bees number 4 finished collecting!
Bees thread 20 was started
Bees thread 21 was started
Bees thread 22 was started
Bees thread 23 was started
Bees thread 24 was started
Bees number 5 finished collecting!
Bees thread 25 was started
Bees thread 26 was started
Bees thread 27 was started
Bees number 6 finished collecting!
Bees thread 28 was started
Bees thread 29 was started
Bees thread 30 was started
Bees thread 31 was started
Bees thread 32 was started
Bees number 7 finished collecting!
Bees thread 33 was started
Bees thread 34 was started
Bees thread 35 was started
Bees thread 36 was started
Bees thread 37 was started
Bees number 8 finished collecting!
Bees thread 38 was started
Bees thread 0 was finished
Bees thread 1 was finished
Bees thread 2 was finished
Bees thread 3 was finished
Bees number 9 finished collecting!
Bees thread 4 was finished
Bees thread 5 was finished
Bees thread 6 was finished
Bees thread 7 was finished
Bees thread 8 was finished
Bees thread 9 was finished
Bees number 10 finished collecting!
Bees thread 10 was finished
Bees number 11 finished collecting!
Bees thread 11 was finished
Bees number 12 finished collecting!
Bees thread 12 was finished
Bees number 13 finished collecting!
Bees thread 13 was finished
Bees number 14 finished collecting!
Bees thread 14 was finished
Bees number 15 finished collecting!
Bees thread 15 was finished
Bees number 16 finished collecting!
Bees thread 16 was finished
Bees number 17 finished collecting!
Bees thread 17 was finished
Bees number 18 finished collecting!
Bees thread 18 was finished
Bees number 19 finished collecting!
Bees thread 19 was finished
Bees number 20 finished collecting!
Bees thread 20 was finished
Bees number 21 finished collecting!
Bees thread 21 was finished
Bees number 22 finished collecting!
Bees thread 22 was finished
Bees number 23 finished collecting!
Bees thread 23 was finished
Bees number 24 finished collecting!
Bees thread 24 was finished
Bees number 25 finished collecting!
Bees thread 25 was finished
Bees number 26 finished collecting!
Bees thread 26 was finished
Bees number 27 finished collecting!
Bees thread 27 was finished
Bees number 28 finished collecting!
Bees thread 28 was finished
Bees number 29 finished collecting!
Bees thread 29 was finished
Bear started gathering honey!
Bear was bited by BEES!
39 bees in the hive!
Bees number 30 finished collecting!
Bees thread 30 was finished
Bear started gathering honey!
2 bees in the hive!
Bear gathered HONEY!!!
Bees number 31 finished collecting!
Bees thread 31 was finished
Bees number 32 finished collecting!
Bees thread 32 was finished
Bees number 33 finished collecting!
Bees thread 33 was finished
Bees number 34 finished collecting!
Bees thread 34 was finished
Bees number 35 finished collecting!
Bees thread 35 was finished
Bees number 36 finished collecting!
Bees thread 36 was finished
Bees number 37 finished collecting!
Bees thread 37 was finished
Bees number 38 finished collecting!
Bees thread 38 was finished
Bees thread 39 was finished
```
Из выходных данных можно заметить, что медведь вышел на охоту, когда в улее было много пчел, поэтому его покусали. 
Во второй раз пчёл стало меньше и медведь свободно собрал весь мёд, а пчела дальше продолжили собирать мёд.


В некоторых моментах, как например этот, медведь не успевает дождаться момента, когда в улее будет мало пчел, поэтому он лежит в спячке и не собирает мёд.
```
35
Bees thread 0 was started
Bees thread 1 was started
Bees thread 2 was started
Bees number 0 finished collecting!
Bees thread 3 was started
Bees thread 4 was started
Bees thread 5 was started
Bees thread 6 was started
Bees thread 7 was started
Bees number 1 finished collecting!
Bees thread 8 was started
Bees thread 9 was started
Bees thread 10 was started
Bees thread 11 was started
Bees thread 12 was started
Bees number 2 finished collecting!
Bees thread 13 was started
Bees thread 14 was started
Bees thread 15 was started
Bees thread 16 was started
Bees number 3 finished collecting!
Bees thread 17 was started
Bees thread 18 was started
Bees thread 19 was started
Bees thread 20 was started
Bees number 4 finished collecting!
Bees thread 21 was started
Bees thread 22 was started
Bees thread 23 was started
Bees thread 24 was started
Bees thread 25 was started
Bees number 5 finished collecting!
Bees thread 26 was started
Bees thread 27 was started
Bees thread 28 was started
Bees thread 29 was started
Bees number 6 finished collecting!
Bees thread 30 was started
Bees thread 31 was started
Bees thread 32 was started
Bees thread 33 was started
Bees thread 0 was finished
Bees number 7 finished collecting!
Bees thread 1 was finished
Bees thread 2 was finished
Bees thread 3 was finished
Bees thread 4 was finished
Bees thread 5 was finished
Bees thread 6 was finished
Bees thread 7 was finished
Bees number 8 finished collecting!
Bees thread 8 was finished
Bees number 9 finished collecting!
Bees thread 9 was finished
Bees number 10 finished collecting!
Bees thread 10 was finished
Bees number 11 finished collecting!
Bees thread 11 was finished
Bees number 12 finished collecting!
Bees thread 12 was finished
Bees number 13 finished collecting!
Bees thread 13 was finished
Bees number 14 finished collecting!
Bees thread 14 was finished
Bees number 15 finished collecting!
Bees thread 15 was finished
Bees number 16 finished collecting!
Bees thread 16 was finished
Bees number 17 finished collecting!
Bees thread 17 was finished
Bees number 18 finished collecting!
Bees thread 18 was finished
Bees number 19 finished collecting!
Bees thread 19 was finished
Bees number 20 finished collecting!
Bees thread 20 was finished
Bees number 21 finished collecting!
Bees thread 21 was finished
Bees number 22 finished collecting!
Bees thread 22 was finished
Bees number 23 finished collecting!
Bees thread 23 was finished
Bees number 24 finished collecting!
Bees thread 24 was finished
Bees number 25 finished collecting!
Bees thread 25 was finished
Bees number 26 finished collecting!
Bees thread 26 was finished
Bees number 27 finished collecting!
Bees thread 27 was finished
Bees number 28 finished collecting!
Bees thread 28 was finished
Bear started gathering honey!
Bear was bited by BEES!
34 bees in the hive!
Bees number 29 finished collecting!
Bees thread 29 was finished
Bees number 30 finished collecting!
Bees thread 30 was finished
Bees number 31 finished collecting!
Bees thread 31 was finished
``` 
